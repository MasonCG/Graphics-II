#pragma once

#include "ext/json11.h"

//~ class Json{
  //~ public:
    //~ typedef std::vector<Json> list;
    //~ typedef std::map<std::string,Json> dict;

    //~ typedef std::variant< double,nullptr,bool,std::string,list,dict> > JsonData;

    //~ static Json parse(const std::string& data);

    //~ JsonData& operator[](const std::string key);
    //~ const JsonData& operator[](const std::string key) const;


  //~ private:
    //~ json11::Json J;
    //~ Json(const json11::Json& JJ);
//~ };
