class Globals;

void setup(Globals* globs);
