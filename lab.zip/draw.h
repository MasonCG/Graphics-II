class Globals;

void draw(Globals* globs);
