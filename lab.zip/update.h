class Globals;

void update(Globals* globs, float elapsed);